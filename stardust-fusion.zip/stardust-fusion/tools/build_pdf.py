#!/usr/bin/env python3
# build_pdf.py — Genera GUIA_NOVATOS.pdf (y un PDF consolidado del libro completo)
# desde los Markdown de docs/. Usa fpdf2 (pip install fpdf2).
#
# Uso:
#   python3 tools/build_pdf.py            # genera GUIA_NOVATOS.pdf y STARDUST_LIBRO.pdf
import re, os, sys

try:
    from fpdf import FPDF
except ImportError:
    sys.exit("Falta fpdf2. Instala con: pip install fpdf2")

DOCS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "docs")
OUT  = os.path.dirname(DOCS)

ACCENT_MAP = str.maketrans({
    "á":"a","é":"e","í":"i","ó":"o","ú":"u","ü":"u","ñ":"n","¿":"?","¡":"!",
    "Á":"A","É":"E","Í":"I","Ó":"O","Ú":"U","Ü":"U","Ñ":"N",
    "—":"-","–":"-","“":'"',"”":'"',"‘":"'","’":"'","…":"...",
    "│":"|","┌":"+","┐":"+","└":"+","┘":"+","─":"-","►":">","◄":"<","≈":"~",
})

def clean(s):
    return s.translate(ACCENT_MAP)

class Book(FPDF):
    def __init__(self, title):
        super().__init__()
        self.booktitle = title
        self.set_auto_page_break(True, margin=14)
    def header(self):
        if self.page_no() > 1:
            self.set_font("Helvetica","I",8)
            self.set_text_color(120,120,120)
            self.cell(0,5,clean(self.booktitle),align="R")
            self.ln(7)
            self.set_text_color(0,0,0)
    def footer(self):
        self.set_y(-12)
        self.set_font("Helvetica","I",8)
        self.set_text_color(120,120,120)
        self.cell(0,5,f"pag. {self.page_no()}",align="C")

INLINE_RE = re.compile(r"\*\*(.+?)\*\*|\*(.+?)\*|`(.+?)`")

def write_rich(pdf, text, size=10, style=""):
    pos = 0
    for m in INLINE_RE.finditer(text):
        if m.start() > pos:
            pdf.set_font("Helvetica",style,size); pdf.write(4.6, clean(text[pos:m.start()]))
        if m.group(1) is not None:
            pdf.set_font("Helvetica","B",size); pdf.write(4.6, clean(m.group(1)))
        elif m.group(2) is not None:
            pdf.set_font("Helvetica","I",size); pdf.write(4.6, clean(m.group(2)))
        else:
            pdf.set_font("Courier","",max(size-1,7)); pdf.write(4.6, clean(m.group(3)))
        pos = m.end()
    if pos < len(text):
        pdf.set_font("Helvetica",style,size); pdf.write(4.6, clean(text[pos:]))
    pdf.ln(5.2)

def flush_table(pdf, rows):
    if not rows: return
    ncol = max(len(r) for r in rows)
    rows = [r + [""]*(ncol-len(r)) for r in rows]
    w = (pdf.epw - 4) / ncol
    pdf.set_font("Helvetica","",7.8)
    for ri, row in enumerate(rows):
        if ri == 1 and all(re.match(r"^:?-{2,}:?$", c) for c in row if c):
            continue
        cells = [re.sub(r"\*\*(.+?)\*\*", r"\1", clean(c))[:70] for c in row]
        h = 5
        try:
            if pdf.get_y() + h > pdf.page_break_trigger: pdf.add_page()
            if ri == 0: pdf.set_fill_color(235,240,250)
            else: pdf.set_fill_color(255,255,255)
            for c in cells:
                pdf.cell(w, h, c, border=1, fill=(ri==0))
            pdf.ln(h)
        except Exception:
            pdf.multi_cell(0,4.5," | ".join(cells))

def render_md(pdf, path, base_size=10):
    lines = open(path, encoding="utf-8").read().splitlines()
    i, in_code, table_buf = 0, False, []
    while i < len(lines):
        ln = lines[i]
        if ln.strip().startswith("```"):
            flush_table(pdf, table_buf); table_buf = []
            in_code = not in_code
            if in_code:
                pdf.set_fill_color(245,245,245); pdf.set_font("Courier","",7.6)
                pdf.ln(1.5)
            else:
                pdf.ln(1.5)
            i += 1; continue
        if in_code:
            if pdf.get_y() > pdf.page_break_trigger: pdf.add_page()
            pdf.cell(0, 4.2, clean(ln[:150]) or " ", new_x="LM", new_y="NEXT", fill=True)
            i += 1; continue
        s = ln.strip()
        if s.startswith("|") and s.endswith("|"):
            table_buf.append([c.strip() for c in s.strip("|").split("|")])
            i += 1; continue
        flush_table(pdf, table_buf); table_buf = []
        if not s:
            pdf.ln(2); i += 1; continue
        if s.startswith("# "):
            pdf.set_font("Helvetica","B",16); pdf.set_text_color(30,60,120)
            pdf.multi_cell(0,7,clean(s[2:])); pdf.set_text_color(0,0,0); pdf.ln(2)
        elif s.startswith("## "):
            pdf.set_font("Helvetica","B",13); pdf.set_text_color(40,90,150)
            pdf.multi_cell(0,6,clean(s[3:])); pdf.set_text_color(0,0,0); pdf.ln(1.5)
        elif s.startswith("### "):
            pdf.set_font("Helvetica","B",11); pdf.set_text_color(60,110,160)
            pdf.multi_cell(0,5.5,clean(s[4:])); pdf.set_text_color(0,0,0); pdf.ln(1)
        elif s.startswith("<a name") or s == "---":
            pass
        elif s.startswith("> "):
            pdf.set_font("Helvetica","I",base_size-1); pdf.set_text_color(90,90,90)
            pdf.set_x(pdf.l_margin + 4)
            pdf.multi_cell(0,4.8,clean(s[2:])); pdf.set_text_color(0,0,0); pdf.ln(1)
        elif re.match(r"^\d+\.\s", s) or s.startswith("- ") or s.startswith("* "):
            txt = re.sub(r"^(\d+)\.\s+", r"\1) ", s)
            indent = 2
            pdf.set_x(pdf.l_margin + indent)
            write_rich(pdf, txt, base_size)
        else:
            write_rich(pdf, s, base_size)
        i += 1
    flush_table(pdf, table_buf)

def build():
    guia = os.path.join(DOCS, "GUIA_NOVATOS.md")
    pdf = Book("StarDust Fusion - Guia para novatos")
    pdf.add_page()
    pdf.set_font("Helvetica","B",22); pdf.set_text_color(30,60,120)
    pdf.multi_cell(0,10,clean("StarDust Fusion"))
    pdf.set_font("Helvetica","",12); pdf.set_text_color(0,0,0)
    pdf.multi_cell(0,6,clean("Guia completa para novatos (motor + BlocksDS + cartuchos) - Fase 1"))
    pdf.ln(4)
    render_md(pdf, guia)
    p1 = os.path.join(OUT, "GUIA_NOVATOS.pdf")
    pdf.output(p1); print("OK ->", p1)

    libro = Book("StarDust Fusion - El Libro")
    libro.add_page()
    root = os.path.dirname(DOCS)
    partes = [("MEMORIA_PROYECTO.md", root)] + [(f, DOCS) for f in (
        "API_REFERENCE.md","ARM7_AUTONOMY.md","BUILD_BLOCKSDS.md","CROSSPLAY_PC.md",
        "CARTUCHOS_RAM.md","TOOLS.md","VERSIONES_HERMANAS.md","DESECHADOS.md")]
    for fname, d in partes:
        fp = os.path.join(d, fname)
        if os.path.exists(fp):
            libro.set_font("Helvetica","B",15); libro.set_text_color(30,60,120)
            libro.multi_cell(0,8,clean(fname.replace(".md",""))); libro.set_text_color(0,0,0)
            render_md(libro, fp)
            libro.add_page()
    p2 = os.path.join(OUT, "STARDUST_LIBRO.pdf")
    libro.output(p2); print("OK ->", p2)

if __name__ == "__main__":
    build()
