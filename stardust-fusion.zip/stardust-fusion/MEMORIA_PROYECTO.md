# MEMORIA_PROYECTO.md — StarDust-DS Fusion (documento de memoria persistente)

> **Si eres una IA y acabas de perder el contexto: LEE ESTE ARCHIVO ENTERO PRIMERO.**
> Aquí está TODO el estado verificado del proyecto. Última actualización: 2026-10-03.

## 1. Qué es esto
Fusión definitiva del motor 3D **StarDust-DS** (Yackerw) combinando los aportes reales
de sus forks/ejemplos, portado a **BlocksDS**, con documentación etiquetada y APIs para
**cartuchos personalizados con RAM extra** y **crossplay DS↔PC**.

## 2. Árbol genealógico VERIFICADO (git merge-base + git log, no de memoria)
| Repo | Verdad verificada |
|---|---|
| `Yackerw/StarDust-DS @ main` | **BASE OFICIAL de la fusión.** Ya contiene el port a calico (arm7 usa `<calico.h>`, `pxiReply(PxiChannel_User0,...)`, `wlmgrStartServer()`, `pmMainLoop()`). Superó a todos los forks. |
| `rainscut` | Ancestro puro de main: `main..rainscut` = 0 commits únicos. NO aporta nada. No usar como base. |
| `Moricombe` | Ancestro puro de main (41 commits por detrás). Su único aporte NO absorbido: `nitrofs.c/h` (rescatado ✅). |
| `Quest84` | HEAD == merge-base de main (congelado, 67 commits por detrás). Aportes rescatados: `RaycastWorld` (main ya lo tiene MEJORADO con `ITCM_CODE`), `Convert*Palette` (main ya las tiene en sdrender.c:1758+). Prácticamente todo ya estaba absorbido. ❌ su `mm_stream/maxmod9` quedó como experimento documentado, no fusionado. |
| `Example @ 2.0-test` | GJK COMPLETO (`Simplex`, `GJKProcessSimplex2/3/4`, `GJKWithInfo`, `BoxSupport`) + helpers de `sdmath` (`divf32f`, `RestoreMatrixStack`, `PushMatrixStack`). **El `BasicGJK` de main era slop_basura**: bucle `while(true)` sin procesamiento de simplex → reemplazado ✅. |
| `Example @ 1.0` | nitrofs vía Moricombe. |

## 3. Sistema de etiquetado (regla del usuario, DOGMA del proyecto)
- `legacy_` : original Yackerw que funciona; se conserva tal cual.
- `ported_` : legacy adaptado a BlocksDS/calico.
- `new_`    : aporte nuevo (forks o nuestro).
- `slop_funcional` : técnica DIFERENTE que sí aporta aunque sea "fea" o difícil. **SE CONSERVA SIEMPRE** con ficha (ventaja/desventaja/reemplazo). Ej.: PlaySound ARM7 descarta si los 16 canales HW están llenos → determinista, cero malloc; complemento: cola en ARM9.
- `slop_basura` : roto sin técnica (bucle infinito, `!` en vez de `~`). Reparar; si no se puede, reemplazar y dejar la rota documentada. Si no aporta NADA ni siquiera como historia → va a `docs/DESECHADOS.md` con motivo y reemplazo.
- Cada función lleva `// CORRE EN ARM7: si/no // DEPENDE DE ARM9: si/no`.
- Hermanas múltiples (misma tarea, distinta fuente: motor/fork/BlocksDS) se conservan TODAS con tabla "cuándo usar cuál", aunque sean casi indistinguibles.

## 4. Estado de la Fase 1 (hecho en `/workspace/stardust-fusion/`)
Copias de trabajo sobre `source/` de Yackerw-main:
1. ✅ `arm7/source/main.c`: fix `SetSoundPan`/`SetSoundVolume` (`!`→`~` + clamp 0..127, marcados `ported_`); ficha `slop_funcional` completa en `PlaySound`.
2. ✅ `arm9/source/sdcollision.c` ← versión 2.0-test (GJK completo, 1973 líneas); la vieja de main guardada como `arm9/source/legacy_sdcollision_main.c` (referencia del `BasicGJK` slop_basura).
3. ✅ `arm9/source/sdgjksupport.c/h` ← 2.0-test (`BoxSupport`).
4. ✅ `arm9/source/sdmath.c/h` ← 2.0-test (provee `divf32f`, matrix stack que necesita el GJK nuevo). **VERIFICAR en build real** que no rompe otros llamantes (diff de cabeceras solo mostraba AÑADIDOS, no eliminados).
5. ✅ `arm9/source/nitrofs.c/h` ← Moricombe (assets embebidos en ROM).
6. ✅ `arm9/source/sdcartridge.c/h` NUEVO: `legacy_Cartridge_GetRamSizeMb()` (canónica 4/16) HERMANA de `new_CartQuery(CartridgeInfo*)` (topología real vía slot2.h de BlocksDS; 0 = desconocido, nunca inventar). El getter exacto de tamaño slot-2 queda `TODO(verificar-en-tu-instalacion)` a propósito: varía entre releases de BlocksDS.
7. ✅ Crossplay endianness: helpers `new_Crossplay_Write/ReadI32/F32/Vec3` (LE explícito) en `sdnetworking.c/h`, sin tocar `PacketSendTo` legacy. Bug real confirmado: 0 usos de htonl/ntohl en el código original.
8. ✅ Makefiles arm7/arm9 apuntados a `$(BLOCKSDS)/sys $(BLOCKSDS)/nds (+portlibs)` con `$(error ...)` si `BLOCKSDS` no está definido (este era el "fatal error: calico.h" de los issues).

### Pendientes Fase 1 (requieren toolchain real, este sandbox NO tiene devkitARM/BlocksDS)
- ⬜ `make -j` en máquina con BlocksDS → arreglar warnings/includes residuales (p.ej. colisión de símbolos entre sdmath 2.0-test y llamadas nuevas de main; revisar `sdinput`/`sdobject` contra cabeceras 2.0).
- ⬜ Probar `test_collision.nds` (ROM de ejemplo que ejercite BoxOnBox/SphereOnSphere/Ray/GJKWithInfo).
- ⬜ Decidir destino final de `maxmod9/mstream` (Quest84): experimento Fase 2.

## 5. Verdades técnicas confirmadas (para no repetir errores de Meta/Qwen anteriores)
- **NO existe loader .obj** en ningún repo. Lo real: exportadores Blender **solo 2.79** en `source/blender/io_mesh_sdm` e `io_mesh_sda` + conversor C# `source/imageConverter/SDImageConverter`. Pipeline oficial: Blender 2.79 → `.sdm/.sda`.
- **Crossplay PC = GLFW 3.3 + GLEW 2.1** (carpetas `VSDeps/*bin.WIN32/lib-vc2019`), WinSock2 en PC ↔ dsiwifi+lwip en DS. NO SDL. Proyecto VS: `source/StarDust.sln` (Win32/x64, C++14, compatible VS2019/VS2022, Win7–10).
- **No hay WPA2 propio** en ningún fork (grep "wpa" vacío). `DSiWifi_InitDefault(true)` maneja asociación; API propia = Fase 2.
- Licencia: **MIT** ("credit me if you use it"), NO GPL (Meta se equivocó).
- `calico.h` = librería de servicios; **BlocksDS** = toolchain completo. El port a calico YA estaba en main pero los Makefiles seguían apuntando a `$(LIBNDS)` → por eso fallaba el build.
- Hardware extras DSi YA usados por el motor: `keypadStartExtServer()` (ejes X/Y + bisagra) en arm7 → semilla de "eventos únicos DSi".
- Bugs históricos confirmados con línea exacta: `SOUNDCNT &= !((0x7F)<<16)` (línea 142 original), `&= !0x7F` (línea 150), PlaySound sin cola (línea ~85), volumen sin clamp.

## 6. Cartuchos personalizados (visión del usuario — decidir tamaños es SOLO del usuario)
- Nada de límites arbitrarios tipo "16 MB máx": el usuario elegirá módulos W25Q, NAND, bancos, 2×16, 8, 32… La API debe REPORTAR topología, no imponer.
- Dos hermanas documentadas: `legacy_Cartridge_GetRamSizeMb()` (rápida, canónica, buena para eventos DSi) y `new_CartQuery()` (real, para layout de assets externos). Ver `docs/CARTUCHOS_RAM.md`.
- Detección DSi: `isDSiMode()` + `REG_SCFG_EXT`; heap extendido automático en BlocksDS al correr en modo DSi.

## 7. Fases futuras (no empezar sin terminar Fase 1)
- **Fase 2**: buscar/implementar extras NO presentes: NitroFS integrado con loader .sdm, mic/cámara DSi, maxmod9 music streaming (resucitar experimento Quest84), compresión LZ77 de assets, sistema de partículas, API WPA2 sobre wlmgr, tests automatizados.
- **Fase 3**: "motor tipo Unity": launcher/visor PC con viewport + inspector de .sdm + play/stop + drag&drop (ImGui), y pipeline Blender→.sdm asistido (script `blender_to_sdm.py` opcional sobre 2.79).

## 8. Reglas de convivencia con el usuario
- Responder en español. No dar respuestas rápidas sin verificar con grep/diff.
- El usuario valora la documentación tipo libro: cada par legacy/ported/new/slop con ejemplo, ventajas, desventajas, parecidos y recomendación de cuándo usar cuál.
- Nunca borrar código ajeno sin registrarlo en `docs/DESECHADOS.md` con motivo + reemplazo.
