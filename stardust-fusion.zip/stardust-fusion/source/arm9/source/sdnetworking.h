#ifndef __SDNETWORKING
#define __SDNETWORKING
#include <nds.h>
#include "sdsocket.h"
#include "sdmath.h"

#ifndef NETVER
#define NETVER 0
#endif

#ifndef NETAUTH
#define NETAUTH "Stardust Vanilla. Change this to match your game!"
#endif

typedef struct NetworkInstance NetworkInstance;

struct NetworkInstance {
#if STARDUST_NETWORKING
	SocketAbstract* socket;
	IPEndPointAbstract* localEndPoint;
	IPEndPointAbstract** clients;
#endif
	int maxClients;
	int maxPackets;
	bool host;
	bool* clientsUsed;
	unsigned char*** importantStack;
	bool** importantStackUsed;
	int* importantStackPosition;
	int** importantStackSizes;
	unsigned char*** receiveStack;
	bool** receiveStackUsed;
	int* receiveStackPosition;
	int** receiveStackTypes;
	int** receiveStackSizes;
	f32* socketTimeout;
	f32** packetTimeout;
	int* clientIDs;
	int clientNode;
	// authentication ID
	int clientID;
	// host
	void (*gameLayerJoinSend)(int, NetworkInstance*);
	// client
	void (*gameLayerJoinReceive)(NetworkInstance*);
	void (*gameLayerJoinOthers)(int, NetworkInstance*);
	void (*gameLayerDisconnect)(int, int, NetworkInstance*);
	void (**gameLayerPacketProcessing)(unsigned char*, int, int, NetworkInstance*);
	int gameLayerPacketProcessingCount;
	int disconnectEvent;
	int joinEvent;
	int joinOtherEvent;
	bool active;
};

// enforce tight packing here
#pragma pack(push, 1)
typedef struct {
	int unode;
	int uid;
	unsigned short pid;
	unsigned short ptype;
	unsigned char important;
	unsigned char padding;
	unsigned short padding2;
} PacketHeader;
#pragma pack(pop)

extern NetworkInstance* defaultNetInstance;

void InitializeNetworking(int maxPlayers, int maxPackets);
NetworkInstance* CreateNetworkingInstance(int maxClients, int maxPackets);
int RegisterPacketType(void (*receiveCallback)(char*, int, int, NetworkInstance*), NetworkInstance* instance);
void DestroyNetworkingInstance(NetworkInstance* instance);
void StopNetworking(NetworkInstance* instance);
void StartNetworking(bool host, char* ip, int port, NetworkInstance* instance);
void UpdateNetworking(NetworkInstance* instance, f32 deltaTime);
void PacketSendAll(char* data, int len, unsigned short packetType, bool important, NetworkInstance* instance);
void PacketSendTo(char* data, int len, unsigned short packetType, bool important, int id, NetworkInstance* instance);
void CloseConn(int node, int reason, NetworkInstance* instance);

// ============================================================================
// new_Crossplay_* : serializacion explicita little-endian para crossplay DS<->PC
// ----------------------------------------------------------------------------
// POR QUE: PacketHeader ya es little-endian en ambos lados (ARM y x86), PERO la
// carga util (payload) se enviaba cruda: si el juego mete f32/structs con padding
// o un PC manda big-endian (o viceversa), los datos llegan invertidos. Grep
// verificado: cero usos de htonl/ntohl en sdnetworking.c/sdsocket.c (bug real).
// Estos helpers NO cambian el formato de PacketSendTo existente (compatibilidad
// hacia atras = legacy_ intacta); son una capa nueva que el juego usa al armar
// sus payloads. REGLA DEL PROYECTO: todo payload multi-byte por UDP debe pasar
// por new_Crossplay_Write*/Read*.
int  new_Crossplay_WriteF32(char* buf, int pos, f32 v);      // escribe LE4
f32  new_Crossplay_ReadF32(const char* buf, int pos);        // lee LE4
int  new_Crossplay_WriteI32(char* buf, int pos, int v);
int  new_Crossplay_ReadI32(const char* buf, int pos);
int  new_Crossplay_WriteVec3(char* buf, int pos, Vec3* v);   // 3x LE4 fixed16
const char* new_Crossplay_ReadVec3(const char* buf, int pos, Vec3* out);

#endif