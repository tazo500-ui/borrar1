//---------------------------------------------------------------------------------
// sdcartridge.c  --  new_Cartridge_* + legacy_Cartridge_* (ver sdcartridge.h)
// CORRE EN ARM9: si | DEPENDE DE ARM7: no
//
// NOTA DE PORT (ported_): la deteccion de slot-2 usa las primitivas de BlocksDS
// (<nds/slot2.h>: tipos de periferico, expansion RAM con bancos, NAND...). Si tu
// toolchain no expone slot2.h, la query degrada a "modo consola" solamente y
// slot2Size=0 (= desconocido). Regla del proyecto: NUNCA hardcodear un tamano.
//---------------------------------------------------------------------------------
#include "sdcartridge.h"
#include <stddef.h>

#if defined(__has_include)
#  if __has_include(<nds/slot2.h>)
#    include <nds/slot2.h>
#    define SD_HAVE_SLOT2 1
#  endif
#endif
#ifndef SD_HAVE_SLOT2
#  define SD_HAVE_SLOT2 0
#endif

int legacy_Cartridge_GetRamSizeMb(void) {
	// Canonica: 4 MB en DS/DS Lite, 16 MB en DSi (RAM extendida del sistema).
	return isDSiMode() ? 16 : 4;
}

bool new_Cartridge_Query(CartridgeInfo* out) {
	if (out == NULL) return false;
	out->isDSi = isDSiMode();
	// REG_SCFG_EXT solo es fiable en modo DSi.
	out->scfgExt = out->isDSi ? ((REG_SCFG_EXT & 0x800000u) != 0) : false;
	out->baseRamMb = out->isDSi ? 16 : 4;
	out->slot2Size = 0;     // 0 = "desconocido", jamas inventar
	out->slot2Banked = false;
#if SD_HAVE_SLOT2
	// BlocksDS detecta la geometria REAL del device slot-2 (GBA cart, expansion
	// RAM tipo Ewin/iSMM con bancos, modulos SPI NAND tipo W25Q...). Se pregunta,
	// no se asume. Ver docs/CARTUCHOS_RAM.md para el layout de tus modulos.
	int dev = peripheralSlot2GetDeviceType();
	if (dev == PSL2_DEVICE_TYPE_NDS_RAM) {
		out->slot2Banked = true;
		// TODO(verificar-en-tu-instalacion): asignar out->slot2Size con el getter
		// de tamano que exponga TU version de nds/slot2.h (los nombres variaron
		// entre releases de BlocksDS; no adivinar aqui).
	}
#endif
	return true;
}
