#ifndef __SDCARTRIDGE
#define __SDCARTRIDGE
//---------------------------------------------------------------------------------
// new_Cartridge_* : capa de deteccion de hardware y RAM ampliada.
//
// FILOSOFIA DEL PROYECTO (regla acordada): NO hay limites magicos fijos.
//   - La API "hermana" legacy_Cartridge_GetRamSizeMb() existe y devuelve el
//     numero canonico (4 en DS, 16 en DSi) porque sirve para decisiones
//     rapidas y para documentar eventos unicos por consola.
//   - La API nueva new_Cartridge_Query() reporta la TOPOLOGIA REAL: modo de
//     consola + tamano/geometria del cartucho slot-2 detectado por BlocksDS
//     (slot2.h), que soporta modulos W25Q / NAND / banks multiples sin
//     asumir 8/16/32 MB. Tu decides el layout; el motor solo informa.
//
// CORRE EN ARM9: si  |  DEPENDE DE ARM7: no (solo lectura de registros)
//---------------------------------------------------------------------------------
#include <nds.h>
#include <stdbool.h>

typedef struct {
	bool    isDSi;          // isDSiMode(): DSi/DSi XL/3DS(modo DSi)
	bool    scfgExt;        // REG_SCFG_EXT habilitado (mapa de memoria extendido)
	int     baseRamMb;      // 4 (DS/DS Lite) o 16 (DSi). Canonica, no arbitraria.
	unsigned long slot2Size;// bytes visibles del cartucho slot-2 via BlocksDS slot2
	                        // (0 si no hay cartucho slot-2 / no detectable).
	bool    slot2Banked;    // true si el device slot-2 usa banks (SwitchBank necesario)
} CartridgeInfo;

// --- legada/canonica (hermana simple de la query) ---
// Devuelve 4 o 16 segun consola. Usar para: elegir asset pack normal vs HD,
// spawn de "eventos unicos DSi", etc. Simple y barata.
int legacy_Cartridge_GetRamSizeMb(void);

// --- nueva/topologica ---
// Rellena info con lo que reporta el hardware real. Leer docs/CARTUCHOS_RAM.md
// antes de hardcodear cualquier tamano.
bool new_Cartridge_Query(CartridgeInfo* out);

// Ejemplo de uso recomendado (ver docs):
//   CartridgeInfo ci; new_Cartridge_Query(&ci);
//   if (ci.isDSi) { malloc desde heap DSi extendido; cargar .sdm HD; }
//   if (ci.slot2Size > 0) { usar assets externos del modulo W25Q/NAND; }
#endif
