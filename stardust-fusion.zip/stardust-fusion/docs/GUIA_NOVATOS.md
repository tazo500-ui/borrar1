# 📖 GUÍA PARA NOVATOS — StarDust Fusion (en español, sin asumir que sabes C)

> **Para quién es esta guía:** para ti. Sabes Python básico y lógica de programación,
> pero no conoces C. Esta guía traduce todo a términos de Python cuando se puede,
> te dice PASO A PASO qué instalar, qué tocar y qué NO tocar.
>
> **Regla de oro del proyecto:** nada se borra. Cada función tiene "hermanas"
> (versiones que hacen lo mismo de forma distinta). Aquí aprenderás a elegir la correcta.

---

## Índice
1. [¿Qué es esto? Explicado con Python](#1-qué-es-esto)
2. [Las 3 computadoras dentro de tu consola](#2-las-3-computadoras)
3. [Instalación paso a paso (tu primera ROM)](#3-instalación-paso-a-paso)
4. [Anatomía de un proyecto: qué archivo hace qué](#4-anatomía)
5. [Tu primer juego en 10 minutos (código copiable)](#5-tu-primer-juego)
6. [Cómo leer las etiquetas legacy/ported/new/slop](#6-etiquetas)
7. [Modelos 3D desde Blender 2.79 sin saber C](#7-blender)
8. [Sonido: qué función usar según tu caso](#8-sonido)
9. [Cartuchos personalizados: detección DS/DSi/3DS y RAM extra](#9-cartuchos)
10. [Crossplay DS ↔ PC: encenderlo paso a paso](#10-crossplay)
11. [Diccionario C → Python](#11-diccionario)
12. [Errores típicos y cómo se arreglan](#12-errores)

---

<a name="1-qué-es-esto"></a>
## 1. ¿Qué es esto? Explicado con Python

StarDust es un **motor de juego**: una colección de archivos `.c` y `.h` que tú
incluyes en tu proyecto, como cuando en Python haces `import pygame`.

La diferencia:
- En Python: `pip install pygame` y ya.
- Aquí: copias la carpeta `source/` dentro de tu proyecto y un archivo llamado
  `Makefile` (el "requirements.txt" del mundo C) le dice al compilador cómo unir todo.

**Analogías directas:**

| Concepto Python | Concepto aquí | Qué hace |
|---|---|---|
| `import numpy` | `#include "sdmath.h"` | Traer funciones matemáticas |
| `numpy.array([1,2,3])` | `Vec3 v = {1,2,3};` | Guardar 3 números juntos (posición XYZ) |
| `class Sprite:` | `typedef struct {...} Sprite;` | Un "objeto" con campos (x, y, textura) |
| `while True:` del game loop | `while(pmMainLoop()) {...}` | El corazón: se repite 60 veces por segundo |
| `pygame.init()` | `SDSystemInit()` | Encender pantalla, botones, sonido |
| `.pyc` / wheel | `.nds` | El archivo final que corre en la consola/emulador |

Un **struct** en C es como una `dataclass` de Python sin métodos: solo cajitas con nombre.

```c
// C                                          # Python equivalente
typedef struct {                             # @dataclass
    float x, y, z;                           # class Vec3:
} Vec3;                                      #     x: float; y: float; z: float
```

Los **punteros** (`Vec3* p`) son lo más distinto a Python: son la *dirección* de la
variable, no la variable. Piensa en ellos como "la dirección de una casa" vs "la casa".
En Python nunca piensas en esto porque todo es referencia automática. Ver §11.

---

<a name="2-las-3-computadoras"></a>
## 2. Las 3 computadoras dentro de tu consola (¡importante!)

Una DS/DSi tiene **dos CPUs que corren a la vez**, y StarDust usa ambas:

```
┌───────────────┐   correo (PXI/FIFO)   ┌───────────────┐
│  ARM9         │ ◄──────────────────►  │  ARM7         │
│  "el cerebro" │                       │  "el mayordomo"│
│  tu juego,    │                       │  sonido,       │
│  gráficos,    │                       │  WiFi, botones │
│  física       │                       │  de arranque   │
└───────────────┘                       └───────────────┘
        + en DSi/3DS: hardware extra (más RAM, cámaras, micrófono)
```

- **ARM9** = los archivos en `source/arm9/source/` → ahí programas TU juego.
- **ARM7** = `source/arm7/source/main.c` → casi nunca lo tocas; el motor le manda
  "recados" por el canal de correo `PxiChannel_User0`.

**En Python sería:** tu script principal (ARM9) mandando mensajes a un hilo
de fondo (ARM7) que atiende audio y red. Tú solo escribes el principal.

Cuando la documentación dice *"CORRE EN ARM7: sí/no"* te dice en qué CPU vive esa
función. Si escribes tu juego, usas las de ARM9 y el motor llama a las de ARM7.

---

<a name="3-instalación-paso-a-paso"></a>
## 3. Instalación paso a paso (desde cero, Windows o Linux)

### Paso 1 — Instalar BlocksDS (el compilador)
BlocksDS reemplaza al viejo devkitPro/libnds (está muerto; ver BUILD_BLOCKSDS.md).

**Windows:** descarga el instalador `.exe` de https://github.com/BlocksDS/blockstsds/releases
(ejecútalo, instala en `C:\BlocksDS`, acepta agregar al PATH).
**Linux/macOS:**
```bash
git clone --recursive https://github.com/BlocksDS/blocksds.git
cd blocksds && make -j$(nproc) && sudo make install
```
Verifica: abre una terminal nueva y escribe `arm-none-eabi-gcc --version`.
Si muestra una versión, vas bien. Si dice "no existe", el PATH no quedó configurado.

### Paso 2 — Bajar este proyecto
Descarga el ZIP de este repositorio (botón verde Code → Download ZIP) y descomprímelo.

### Paso 3 — Compilar el ejemplo
```bash
cd stardust-fusion/source
make -j4
```
Salida esperada: un archivo `.nds` (por ejemplo `build/arm9/arm9.nds` o similar según
el Makefile). **Si falla con "calico.h not found"** → BlocksDS no está instalado o el
PATH apunta a otro lado; vuelve al Paso 1.

### Paso 4 — Probarlo
- **Emulador (recomendado para empezar):** melonDS (PC) o DraStic (Android).
  En melonDS activa "DSi mode" para probar también las rutas DSi.
- **Consola real:** flashcart (TWiLight Menu++ en DS/DSi). Para tus cartuchos
  caseros con W25Q ver docs/CARTUCHOS_RAM.md.

> ⚠️ **Honestidad:** este entorno donde se generó el código no tiene toolchain ARM,
> así que el `make` se probó parcialmente. Si algo truena, pégame el error y lo arreglo;
> los errores de compilación en C siempre dicen archivo y línea, eso basta.

---

<a name="4-anatomía"></a>
## 4. Anatomía de un proyecto: qué archivo hace qué

Todo está en `source/arm9/source/`. Cada par `.h`+`.c`: el `.h` es el **menú**
(declara funciones), el `.c` es la **cocina** (las implementa). Tú solo lees menús.

| Archivo | ¿Qué hace? (una frase) | Equivalente mental |
|---|---|---|
| `main.c` | Ejemplo de juego completo que puedes copiar como plantilla | tu `app.py` |
| `sdobject.c/h` | Crear/mover/rotar modelos 3D, animaciones, sprites 2D | `GameObject` de Unity |
| `sdrender.c/h` | La cámara, luces, fondos, pantallas táctiles | `Camera` + `Renderer` |
| `sdcollision.c/h` | Colisiones esfera/caja/rayo/malla + GJK | `Physics.CheckSphere` |
| `sdgjksupport.c/h` | Motor interno de colisión convexa (rescatado del Example 2.0) | pieza de `Physics` |
| `sdsound.c/h` | Efectos, música, streaming desde SD | `pygame.mixer` |
| `sdnetworking.c/h` | Crossplay DS↔PC por WiFi (con serialización LE nueva) | `socket` + struct empaquetado |
| `sdsocket.c/h` | Capa baja de sockets (lwip en DS, WinSock en PC) | la librería socket cruda |
| `sdinput.c/h` | Botones, cruceta, lápiz/táctil | `pygame.key.get_pressed()` |
| `sdmath.c/h` | Vectores, matrices, quaterniones, `mulf32` fijo | `numpy` chiquito |
| `sdfile.c/h` | Leer/escribir en tarjeta SD (guardar partidas) | `open(path,'rb')` |
| `nitrofs.c/h` | Leer archivos **dentro** de tu .nds (assets embebidos, rescatado de Moricombe) | `pkg_resources` |
| `sdcartridge.c/h` | Detectar consola y RAM extra (NUEVO, para tus cartuchos) | `platform` + `psutil` |
| `sddelta.c/h` | Compresión delta de datos (menos MB en ROM) | `zlib` casero |
| `legacy_sdcollision_main.c` | El `BasicGJK` roto conservado como museo (slop_basura) | código deprecated intocable |

Y afuera del C:
- `source/blender/blender/io_mesh_sdm/` → plugin exportador **.sdm** para Blender 2.79.
- `source/imageConverter/` → conversor C# de imágenes PNG→texturas StarDust.
- `PC/` → proyecto Visual Studio del side de PC del crossplay (GLFW+GLEW).

---

<a name="5-tu-primer-juego"></a>
## 5. Tu primer juego en 10 minutos (copiable tal cual)

Esta plantilla usa **solo funciones verificadas en los headers reales** del proyecto
(`sdrender.h`, `sdsound.h`, `sdobject.h`). Copia, pega, compila:

```c
#include <nds.h>          // "import nds"       -> botones, pantalla, hardware
#include "sdrender.h"     // modelos 3D, camara, luces, sprites
#include "sdsound.h"      // sonido
#include "sdobject.h"     // objetos con logica/collision (estilo Unity GameObject)
#include "sdcartridge.h"  // deteccion DS/DSi/RAM extra (NUEVO de esta fusion)

// struct = dataclass sin metodos. Aqui guardamos las cosas que creamos al inicio.
typedef struct {
    Model*  cube;         // * = puntero: 'la direccion' del modelo, no el modelo
    Vec3    position;     // posicion XYZ (Vec3 vive en sdmath.h)
    Quaternion rot;       // rotacion
} Game;

int main(void) {
    Game g;
    InitSound();                              // like pygame.mixer.init()
    Initialize3D(false, true);                // enciende el motor 3D (pantalla principal)

    g.cube = LoadModel("cube.sdm");           // cargar modelo .sdm (devuelve puntero)
    if (g.cube == NULL) return 1;             // == None en Python
    // f32 aqui es numero FIJO con 12 bits decimales: 1.0 == 4096, 5.0 == 20480
    g.position = (Vec3){0, 0, 5 * 4096};      // frente a la camara

    Set3DOnTop();                             // el 3D sale en la pantalla de arriba
    SetLightColor(0, 16, 16, 16);             // luz 0 blanca (R,G,B 0..31) - como main.c oficial
    SetAmbientColor(8, 8, 8);                 // ambiente gris
    SetLightDir(0, -4096, 0);                 // luz cayendo desde arriba (fijo: -4096 = -1.0)

    // evento por consola: huevo de pascua DSi (API nueva, ver §9)
    CartridgeInfo ci; new_Cartridge_Query(&ci);
    if (ci.isDSi) printf("Modo DSi: contenido HD activado\n");

    int angle = 0;
    while (pmMainLoop()) {                    // game loop ~60fps (while True:)
        scanKeys();                           // actualizar variables held/pressed
        if (held & KEY_A)                     // boton A mantenido
            PlayMusic("theme.wav", 0);        // una sola vez basta para arrancar musica

        angle += 8;                           // girar poco a poco cada frame
        RenderModel(g.cube, &g.position, NULL, &g.rot, NULL, 0); // dibujar el frame
    }
    return 0;
}
```

**Cómo adaptar esto a tu idea (receta):**
1. Modela tu objeto en Blender 2.79 → expórtalo `.sdm` (§7).
2. Pon el `.sdm` junto a tu ROM (o dentro vía NitroFS, §4) y cárgalo con `LoadModel("tunombre.sdm")`.
3. Muévelo cambiando los campos de `g.position` (xyz) y pásaselo a `RenderModel(...)`.
   Para animaciones con huesos: `RenderModelRigged(model, pos, scale, rot, mats, animator, prio)`
   + `CreateAnimator(model)` + `PlayAnimation(animator, LoadAnimation("run.sda"), 0)`.
4. Checa botones con `scanKeys()` + `held` (mantenido) / `pressed` (recién tocado).
5. Colisiones simples: `SphereOnSphere(s1,s2,&penetracion,&normal)` o rayos contra
   mundo con `RaycastWorld(origen, direccion, largo, capa, &t, &hit)` (esta última
   rescatada de Quest84 como `new_`). Física convexa general: `GJKWithInfo` + `BoxSupport`.

---

<a name="6-etiquetas"></a>
## 6. Cómo leer las etiquetas (el sistema que pediste)

Delante de cada función en los headers hay una etiqueta. Significa:

| Etiqueta | Qué es | Regla práctica |
|---|---|---|
| `legacy_` | Original de Yackerw, funciona igual | úsala si te gusta su técnica o necesitas compatibilidad exacta |
| `ported_` | Legacy adaptada a BlocksDS | **tu opción por defecto** |
| `new_` | Aporte nuevo (fork, example 2.0, o nosotros) | úsala para cosas que antes no existían |
| `slop_funcional` | Fea pero es una **técnica distinta válida** | se conserva; lee sus VENTAJAS antes de descartarla |
| `slop_basura` | Bug puro (bucle infinito, `!` en vez de `~`) | **NO la uses**; su reparación/replace está documentado junto a ella |

Ejemplo real leído del código (ARM7):
```c
// CATEGORIA: slop_funcional (tecnica distinta que SI aporta; se conserva)
// TECNICA: si llenas los 16 canales de sonido, devuelve -1 y TU decides
// VENTAJA: determinista, cero malloc en ARM7
// DESVENTAJA: pierdes el sonido si no controlas
// REEMPLAZO: new_Sound_QueuePlay() (cola software en ARM9)
```
Traducción: "esta función te avisa cuando el escenario de sonido está lleno en vez
de hacer cola. Úsala si quieres control total; si no, usa la hermana con cola."

**Versiones hermanas completas** (todas las familias, cuál elegir, cuándo): están en
`docs/VERSIONES_HERMANAS.md`. Esa es la tabla grande que pediste; este §6 solo te
enseña a leer las etiquetas.

---

<a name="7-blender"></a>
## 7. Modelos 3D desde Blender 2.79 sin saber C

Flujo oficial del motor (verificado leyendo el plugin):

1. Abre **Blender 2.79** (sí, versión vieja; el plugin usa APIs eliminadas en 2.8+).
2. Modela tu objeto. Convenciones del exportador:
   - Escala: 1 unidad Blender ≈ 1 unidad StarDust (los vértices se cuantizan a int16).
   - Nombres de materiales = indices de paleta (ponles `mat0`, `mat1`...).
   - Animación: huesos (armature); el fix de Moricombe permite huesos sin vertex group.
3. `File → Export → Stardust model (.sdm)` ← el plugin agrega este menú al instalarse.
4. Texturas: prepara PNG 128×128 (o 256×256 en DSi con RAM extra) y pásalo por
   `source/imageConverter/SDImageConverter` (ejecutable `.exe`, arrastra el PNG encima).
   Sale un archivo de textura que el motor carga directo.
5. Copia `.sdm` + textura a la carpeta de assets de tu juego.

Instalación del plugin en 2.79: `File → User Preferences → Add-ons → Install from Disk`
y eliges `source/blender/blender/io_mesh_sdm/__init__.py` (y también `io_mesh_sda`
para animaciones). Detalles finos (soporte 2bpp, alpha 5-bit) en `docs/TOOLS.md`.

> 💡 Si algún día quieres automatizar esto en **Python**: Blender 2.79 trae consola
> Python integrada (`Alt+P`), y puedes exportar en lote con `blender -b archivo.blend -P script.py`.
> Es la vía natural para tu launcher estilo Unity de Fase 3.

---

<a name="8-sonido"></a>
## 8. Sonido: qué función usar según tu caso

Tres hermanas conviven (nadie borrada, todas documentadas):

| Quiero... | Uso (nombre REAL verificado en `sdsound.h`) | Por qué |
|---|---|---|
| Un efecto corto (salto, disparo) | `LoadWav("jump.wav")` → `PlaySound(&datos)` | carga el wav y lo manda a los 16 canales HW del ARM7 |
| Cargar sonido sin congelar el juego | `LoadWavAsync("big.wav", callback, dato)` | carga en segundo plano como un thread de Python |
| Música larga de fondo | `PlayMusic("theme.wav", 0)` + `UpdateMusicBuffer()` cada frame | streaming: lee pedazos, casi no usa RAM |
| Música sin archivo (cartucho/SD lento) | `LoadWavStreamed("song.wav")` | trocea el wav para tocarlo mientras se llena |
| Parar un efecto | `StopSoundEffect(id)` | id = lo que devolvió PlaySound |
| Paneo/volumen por canal | `SetSoundPan(id, pan)` / `SetSoundVolume(id, vol)` | ahora con clamp y `~` correctos (ported_) |

**Dos técnicas legítimas conviviendo (tu regla):** ruta *cruda* (el motor escribe
muestras directo en los registros PCM del ARM7 — técnica original, cero dependencias,
latencia mínima, pero si llenas los 16 canales recibe `-1` y TÚ decides) vs ruta de
*archivo* (cargas .wav/.sdi y el loader arma los canales por ti). Ambas se quedan
documentadas; la tabla completa de hermanas está en `docs/VERSIONES_HERMANAS.md` §Familia 1.
El experimento de música vía maxmod9 (Quest84) NO se fusionó todavía — está anotado
en `docs/DESECHADOS.md` §aplazados con la razón exacta.

---

<a name="9-cartuchos"></a>
## 9. Cartuchos personalizados: detectar tu hardware (tu idea de eventos/anti-piratería)

Lo que pediste: *"que detecte si estoy en DS, DSi o 3DS, cuántos slots/memorias uso,
y poder poner huevos de pascua u objetos únicos según hardware"*.

API nueva en `sdcartridge.h` (corre en ARM9):

```c
CartridgeInfo info;
new_Cartridge_Query(&info);        // llena TODOS los campos que pueda detectar

if (info.isDSi) {                  // DSi o superior (3DS corre juegos DSi en modo TWL!)
    spawn_secret_dsi_object();     // evento exclusivo DSi
}
if (info.slot2Banked) {            // cartucho con RAM/NAND extra (tus modulos W25Q)
    load_hd_assets_from_bank();    // texturas 256x256, segundo nivel, etc.
}
```

**Sobre "detectar 3DS":** honesto y comprobado — desde dentro de un juego DS **no se
puede distinguir DSi de 3DS en modo retro**: el 3DS emula el entorno DSi idéntico
(la BIOS reporta lo mismo). Lo que SÍ puedes hacer:
- Detectar **DS vs DSi/3DS** con `isDSiMode()` ✔ (ya implementado).
- Detectar **RAM extendida activa** con `REG_SCFG_EXT` ✔ (ya implementado).
- Tu truco híbrido ✔: un cartucho slot-2 con microcontrolador (STM32F4) que responde
  a lecturas específicas → eso lo detectas TÚ leyendo direcciones del cartucho. La
  función `new_Cartridge_ReadExtended(direccion, buffer, largo)` está **planificada**
  para ese handshake (está en DESECHADOS.md §aplazados con su diseño exacto; la base
  de lectura slot-2 ya existe vía `sdfile`/lectores de cartucho). Tu firmware del STM32
  decide qué valor devolver (número de serie, estado del diodo, resistencia
  anti-piratería) y el juego dispara eventos según eso. Ejemplo de protocolo sugerido
  (magic + version + flags) en `docs/CARTUCHOS_RAM.md` §Handshake-periferico.
- Sobre "usar el cartucho como nativo 3DS con dos juegos en uno": la interfaz slot-2
  de DS/DSi no habla el protocolo NAND de cartucho 3DS; eso requiere hardware tipo
  3DS-native (otro proyecto). Pero **dentro de un mismo juego** sí puedes tener
  "contenido DS" + "contenido DSi-HD" condicionados por detección — eso es lo que la
  API anterior habilita, y es lo alcanzable hoy.

La versión canónica simple sigue viva al lado: `legacy_Cartridge_GetRamSizeMb()`
(devuelve 4 o 16; útil para decisiones rápidas, documentada como hermana menor).

---

<a name="10-crossplay"></a>
## 10. Crossplay DS ↔ PC: encenderlo paso a paso

Arquitectura real (verificada en código): PC usa **GLFW + GLEW** (OpenGL) y WinSock2;
DS usa lwip sobre el WiFi de DSi. El bug histórico era que los payloads viajaban
**crudos** (cero `htonl/ntohl` en el original — verificado con grep). Fix Fase 1: capa
nueva de serialización little-endian explícita en `sdnetworking.h`:

```c
// ARMAR un paquete desde tu juego (ambos lados usan ESTOS helpers, nunca structs crudos):
char buf[64]; int pos = 0;
pos = new_Crossplay_WriteI32(buf, pos, playerID);      // entero LE
pos = new_Crossplay_WriteF32(buf, pos, x);             // float LE
pos = new_Crossplay_WriteVec3(buf, pos, &position);    // XYZ fijo LE (3x4 bytes)
PacketSendTo(buf, pos, myPacketType, true, node, instance); // la red legacy intacta debajo

// LEER al recibir (en tu callback de RegisterPacketType):
int id = new_Crossplay_ReadI32(data, 0);
f32  x = new_Crossplay_ReadF32(data, 4);
new_Crossplay_ReadVec3(data, 8, &position);
```

Pasos para encenderlo:
1. **PC:** abre `source/StarDust.sln` en Visual Studio 2019/2022 (toolset v142,
   C++14, compatible Win7–Win10), configuración Release x86/x64 del proyecto PC.
   Necesitas la IP de tu PC en la LAN.
2. **DS/DSi:** en tu `main.c`: `InitializeNetworking(maxPlayers, maxPackets)` →
   `CreateNetworkingInstance(...)` → `StartNetworking(host?, "ip-del-pc", puerto, inst)`.
   La consola debe estar en la misma red WiFi.
3. Cada frame llama `UpdateNetworking(instance, dt)` en ambos lados. Registra tus
   tipos de paquete con `RegisterPacketType(tuCallback, instance)`.
4. Prueba primero **dos instancias en PC** antes de meter hardware real; luego melonDS
   con WiFi passthrough; al final DSi real.

Diagrama de paquetes, puertos y por qué estaba roto: `docs/CROSSPLAY_PC.md`.

---

<a name="11-diccionario"></a>
## 11. Diccionario C → Python (chuleta rápida)

```c
int x = 5;                 # x = 5
float v[3];                # v = [0.0, 0.0, 0.0]   (tamaño FIJO, no hay append)
Vec3* p = &cube;           # p = cube   (pero en C debes desreferenciar: (*p).x  o  p->x)
(*p).x = 1;  ==  p->x = 1; # p.x = 1
if (p != NULL)             # if p is not None
for (int i=0;i<n;i++)      # for i in range(n)
void Play(SoundData* s)    # def play(s):   (el * significa "recibo la dirección,
                           #  puedo MODIFICAR el original"; en Python pasarías un objeto mutable)
typedef struct {...} Name; # @dataclass class Name: (sin métodos)
#include "x.h"             # import x   (pero literalmente pega el texto ahí)
make                     # pip install -e .   (compila todo con las reglas del Makefile)
```

Cosas que NO existen en C y te van a sorprender:
- No hay listas dinámicas ni diccionarios: se usan arreglos fijos + contador.
- No hay garbage collector: si algo salió de `malloc`, alguien debe `free`arlo
  (en StarDust el motor lo hace por ti en sus funciones `Destroy*`).
- Los floats son lentos en DS: el motor usa **fijo** (`mulf32(a,b)` = multiplicar
  con precisión de videojuego). Si ves `f32`, es lo mismo que `float` pero con
  alma de entero desplazado.

---

<a name="12-errores"></a>
## 12. Errores típicos y arreglo

| Mensaje del compilador | Traducción | Arreglo |
|---|---|---|
| `fatal error: calico.h: No such file` | No encuentra BlocksDS | Reinstalar/Paso 1; verificar `echo $BLOCKSDS` o PATH |
| `undefined reference to 'SD...'` | Olvidaste compilar ese `.c` | Revisa que tu Makefile incluya el archivo en SOURCES |
| `'X' undeclared` | Usaste algo sin `#include` del header | Agrega el `#include` de la tabla §4 |
| warning: `passing arg discards 'const'` | Intentas modificar algo de solo lectura | Copia antes de modificar |
| La ROM corre en emulador pero no en consola | Tarjeta SD/formato | Usa FAT32 primaria; prueba en melonDS con SD real |

---

## ¿Y la página web?
Se generó `web/index.html` (misma información, visual, con enlaces internos) y
`GUIA_NOVATOS.pdf` para leer offline. Si prefieres la Fase 3 "estilo Unity"
(launcher Python con visor de .sdm, inspector, drag&drop de Blender), está
planificada en `MEMORIA_PROYECTO.md` §Fases; el pipeline Blender→.sdm que
aprendiste en §7 es exactamente el formato de entrada que ese visor consumirá.
