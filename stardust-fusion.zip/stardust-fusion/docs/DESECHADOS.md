# DESECHADOS.md — Cosas que NO se fusionaron y por qué

> Regla del proyecto: nada se borra en silencio. Si algo queda fuera de la fusión, vive aquí
> con su motivo, su evidencia y su reemplazo (o su ruta de recuperación si algún día cambia
> el contexto). También se registran aquí los **mitos desmentidos** para que ninguna IA futura
> los vuelva a dar como verdad.

---

## D-1 · "Loader OBJ experimental de rainscut (`pc/objLoader.c`)"
- **Veredicto:** NO EXISTE. Mito nacido en instrucciones de Meta; Qwen lo repitió; la
  verificación con `grep -r obj` en los 3 forks + main no encuentra ningún loader `.obj`.
- **Qué existe en su lugar:** exportadores de Blender 2.79 → `.sdm/.sda`
  (`source/blender/io_mesh_sdm/__init__.py`, documentado en TOOLS.md).
- **Reemplazo funcional:** importar el .obj en Blender 2.79 (trae obj-importer) y exportar sdm.
- **Ruta de recuperación (fase 3):** un `new_OBJ_Load()` real sería ~200 líneas en PC-side
  (visuales Unity-like), pero en DS no tiene sentido con el pipeline sdm ya cerrado.

## D-2 · `RayOnAABB` de Quest84 (versión sin normal de impacto)
- **Veredicto:** regresión, descartada como implementación (no como historia).
- **Evidencia:** diff contra Moricombe/main: firma `int RayOnAABB(...)` sin out-param normal;
  main/Moricombe devuelven además la normal necesaria para reaccionar al rebote.
- **Reemplazo:** `RayOnAABB` de main (viva). La firma vieja se conservó SOLO como wrapper
  `new_RaycastWorld` compatible con ejemplos antiguos (VERSIONES_HERMANAS §Familia 3).

## D-3 · maxmod9 / `mm_stream` de Quest84 (streaming musical)
- **Veredicto:** NO fusionado en fase 1. Es la decisión más dolorosa del repo porque es la
  única propuesta de música streaming en todo el ecosistema StarDust.
- **Por qué:** requiere `mmarm7` corriendo en ARM7; el arm7 BlocksDS de main ya usa PXI para
  wlmgr/pm/sound/keypad servers y mezclar ambos dueños del FIFO = colisiones de canales PXI
  y de timers de sonido. Arreglarlo bien = rediseñar el protocolo PXI completo (fase 2+).
- **Estado:** código fuente vivo en `investigation/Quest84/source/arm9/source/sdsound.c`
  (este workspace) para cuando se intente. Ticket fase 2: "maxmod sobre calico o driver propio".
- **Alternativa provisional:** streaming manual de main (funciona, mono, sin crossfade).

## D-4 · `Wifi_InitWPA2()` / `Wifi_Close_Safe()` de Quest84
- **Veredicto:** NO EXISTEN. Mito de las instrucciones originales ("busca wifi.c de Quest84
  para adaptar WPA2"). `grep -rni wpa` = 0 resultados en los 6 repos.
- **Realidad:** Quest84 solo tenía API orientada a WEP sobre dswifi viejo. El soporte WPA/WPA2
  hoy viene gratis desde `DSiWifi_InitDefault(true)` + wlmgr de BlocksDS (ya en main).
- **Reemplazo:** la inicialización actual; para cierre seguro: wrappers nuevos en
  sdnetworking.c (cierre de pcb lwip antes de desconectar) inspirados en la *idea* de Meta.

## D-5 · Base "rainscut" como candidato
- **Veredicto:** descartada con evidencia genealógica: `git log main..rainscut/main` vacío
  → rainscut no tiene NINGÚN commit único; main lo absorbió y le añade 2 fixes encima.
- **Reemplazo:** base oficial Yackerw/main (decisión final fase 1).

## D-6 · Makefiles devkitARM clásicos del HEAD
- **Veredicto:** reemplazados (no borrados: quedan en git history y esta nota).
- **Por qué:** apuntaban a LIBNDS viejo → origen exacto del `fatal error: calico.h` reportado
  en issues. Los nuestros fijan `LIBDIRS := $(BLOCKSDS)/sys $(BLOCKSDS)/nds` con guard
  `$(error BLOCKSDS not set)`. Ver BUILD_BLOCKSDS.md.

## D-7 · Límite duro "16MB máximo" para cartuchos personalizados
- **Veredicto:** descartado como LÍMITE, conservado como API hermana fácil
  (`legacy_Cartridge_GetRamSizeMb`). Tu objeción fue correcta: con módulos W25Q apilables
  (2×16, 8, 32…) un tope fijo es arbitrario. Fuente de verdad real: topología vía slot-2
  (`new_CartQuery`). VERSIONES_HERMANAS §Familia 2.

## D-8 · SDL2 en el renderer PC
- **Veredicto:** mito de instrucciones. El proyecto PC usa **GLFW 3.3 + GLEW 2.1**
  (`source/VSDeps/glfw-3.3.bin.WIN32/lib-vc2019`, `.vcxproj` Win32/x64). No hay SDL en ningún lado.
- **Acción:** documentación corregida en CROSSPLAY_PC.md; VS2019 v142 sigue siendo objetivo válido.

---

## Resumen de decisiones
Descartado por inexistente (mitos): D-1, D-4, D-8. Descartado por regresión/sin aporte: D-2, D-5, D-7(límite).
Reemplazado por versión mejor: D-6. Aplazado con ticket futuro: D-3.
