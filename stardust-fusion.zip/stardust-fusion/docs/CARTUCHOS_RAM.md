# CARTUCHOS_RAM.md — Cartuchos personalizados, RAM extra y eventos por consola

> **Principio rector (decisión del usuario):** no hay límites mágicos. El motor **informa**
> la topología real; tú decides cómo la usas (módulos W25Q apilados, NAND, banks, lo que sea).
> El viejo "tope de 16 MB" queda **descartado como límite** pero **conservado como API fácil**
> (hermana legacy). Ver `DESECHADOS.md` §D-7 y `VERSIONES_HERMANAS.md` §Familia 2.

---

## 1. Los tres planos de memoria que conviene no confundir

| Plano | Qué es | Quién lo ve | API |
|---|---|---|---|
| **RAM interna DS** | 4 MB AXI/WRAM (todas las consolas en modo NDS) | ARM9 siempre | malloc normal |
| **RAM extendida DSi** | +12 MB (total 16) solo con mapa SCFG extendido | ARM9 en `isDSiMode()` | `new_Cartridge_Query().scfgExt` → heap grande |
| **Slot-2 externo** | Tus cartuchos: SRAM/NOR W25Q/NAND con banks | ambos modos si el driver lo detecta | `slot2Size`, `slot2Banked`, `SwitchBank()` |

Los **cartuchos personalizados con RAM extra** viven en el tercer plano. La DSi te da además
el segundo gratis. Son independientes: un juego puede usar "heap DSi para escenas HD" Y
"W25Q de tu cartucho para asset pack completo".

## 2. API entregada (`source/arm9/source/sdcartridge.c/h`)

```c
#include "sdcartridge.h"

CartridgeInfo ci;
new_Cartridge_Query(&ci);      // topología REAL ( BlocksDS slot2 + isDSiMode + REG_SCFG_EXT )

if (ci.isDSi && ci.scfgExt) {
    // 16 MB: texturas 256x256, más entidades, audio de mayor rate
    new_Event_SpawnDSiOnly();          // evento único por consola (tu pedido)
}
if (ci.slot2Size > 0) {
    // cartucho personalizado presente: cargar assets externos
    if (ci.slot2Banked) SwitchBank(0); // geometría reportada, no asumida
    ExternalAsset_Load("title.sdm", ci.slot2Size);
}
// fallback simple (hermana legacy):
int mb = legacy_Cartridge_GetRamSizeMb();   // 4 o 16 — solo para decisiones rápidas
```

**Contrato honesto:** todo campo que el hardware no pueda reportar sale **0/false**, nunca
un número inventado. Si tu módulo W25Q usa un layout exótico que el driver slot-2 de tu
versión de BlocksDS no conoce, `slot2Size` será 0 y debes hablar con el chip directamente
(JEDEC ID 0xEF… para Winbond) — ese driver propio es tarea FASE 2 y está ticketeado abajo.

## 3. Detección DS vs DS Lite vs DSi vs 3DS (tabla práctica)

| Consola | `isDSiMode()` | RAM usable | Notas |
|---|---|---|---|
| DS / DS Lite | false | 4 MB | Compatibilidad total del motor; nada crashea (requisito tuyo: back-compat) |
| DSi / DSi XL | true | 16 MB (con SCFG ext) | Cámara, micrófono, keypad extendido (`keypadStartExtServer` ya corre en nuestro arm7), SD card nativa |
| 3DS en modo NDS | true-ish | 16 MB | Tratar como DSi a menos que uses features propias; probar en hw |

**Eventos únicos:** patrón recomendado = cada `.sdm`/escena declara su requisito y el loader
elige pack: `assets/ds/*.sdm` vs `assets/dsi/*.sdm`; si falta el pack, se degrada al básico
(nunca abortar). Ejemplo completo en API_REFERENCE.md §Cartucho.

## 4. Guía para tus cartuchos con módulos extra (W25Q16/W25Q32/NAND)

- **W25Q16 = 2 MB, W25Q32 = 4 MB, etc.** (nombrar por megabits: 16 Mb = 2 MB — error común
  que te pedí evitar documentar: cuidado con Mb vs MB en datasheets).
- Dos chips de 16 Mb dan 4 MB contiguos si los cableas en banks consecutivos; el motor lo
  soporta porque **no asume un tope**: usa `slot2Banked` + `SwitchBank(n)` por rango.
- Layout sugerido (puede ser otro, es decisión tuya): header 4 KB con magic `SDCART01` +
  tabla de archivos; luego packs DS básicos; luego pack DSi HD. Así UN cartucho funciona
  en ambas consolas y `new_Cartridge_Query` decide qué leer.
- Prueba sin hardware dedicado: de momento BlocksDS reporta tamaños estándar; valida en tu
  placa antes de confiar en `slot2Size` para layouts custom (por eso el getter fino queda
  marcado `TODO(verificar-en-tu-instalacion)` en el código — es a propósito, no flojera).

## 5. Tickets FASE 2 (relacionados, aún no hechos)
1. Driver JEDEC directo para W25Q series cuando slot2.h no reconozca el chip.
2. Compresión LZ77 dentro de `.sdm` (los assets grandes caben mejor en 4 MB).
3. Carga desde tarjeta SD nativa DSi (`blk*` APIs de calico) como alternativa al slot-2.
4. Test ROM `test_cart.nds`: imprime CartridgeInfo y dispara el evento DSi-only visible.
