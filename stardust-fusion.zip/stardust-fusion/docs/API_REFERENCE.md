# API_REFERENCE.md — StarDust-DS Fusion

Sistema de etiquetas (ver `MEMORIA_PROYECTO.md` §3):
`legacy_` original que funciona · `ported_` adaptado a BlocksDS · `new_` aporte nuevo ·
`slop_funcional` técnica distinta válida, se conserva con ficha · `slop_basura` roto sin técnica, reparado o reemplazado.

---

## 🔊 Audio (ARM7 autónomo: escribe directo en 0x04000400; ARM9 solo pide por PXI)

### `PlaySound(SoundData*)` — `slop_funcional` (conservada con ficha completa)
```c
// CATEGORIA: slop_funcional
// TECNICA: descarte SIN cola. Si los 16 canales hardware están ocupados,
//          responde -1 por pxiReply y el juego decide.
// POR QUÉ SE CONSERVA: determinista, O(16), cero malloc en ARM7. Para SFX densos
//   es MEJOR que una cola: perder un footstep duele menos que añadir latencia/heap.
// VENTAJA: rapidísima, predecible, sin heap.
// DESVENTAJA: pierdes sonidos si haces spam sin medir.
// REEMPLAZO/COMPLEMENTO: new_Sound_QueuePlay() (cola software en ARM9, Fase 2).
// CORRE EN ARM7: sí // DEPENDE DE ARM9: solo recibe puntero a samples ya en memoria compartida
```
**Ejemplo:**
```c
SoundData sd = { .sound = &myWav, .volume = inttof32(80), .pan = inttof32(64),
                 .pitch = inttof32(256), .loop = false };
PlaySound(&sd);   // id de canal vía PXI, o -1 si lleno
```
**Nota de pitch:** main ya corrige a los forks viejos: `SOUNDTMR = SOUND_FREQ(mulf32(sampleRate, pitch))`. Moricombe/Quest84 hacían `SOUND_FREQ(sampleRate)` e **ignoraban el pitch** (regresión histórica, no fusionada → DESECHADOS #4).

### `SetSoundPan / SetSoundVolume` — `ported_` (fix de slop_basura)
Original: `SOUNDCNT &= !((0x7F)<<16)` → `!` es NOT **lógico** (0 o 1): limpiaba TODO el registro o nada. Corregido in-place a `~` + clamp 0..127 (bug puro, no técnica alternativa).
**Cuándo usar qué:** mutar un canal vivo → estas; reproducir algo nuevo → `PlaySound`.

---

## 🥊 Colisiones (`sdcollision.c` ← Example 2.0-test)

### `BasicGJK(...)` — `new_` (reemplazo del BasicGJK slop_basura de main)
El de main tenía `while(true)` sin procesar el simplex: colgaba o devolvía basura. La versión 2.0-test añade `Simplex{points,count}`, `GJKProcessSimplex2/3/4`, `GJK_LENIENCY 32` (tolerancia fija para f32).
```c
Simplex s = {0};
Vec3 n = sub(pB, pA);            // forma esperada: shape2 - shape1
bool hit = BasicGJK(shapeA, shapeB, &n, &s, findSupportA, findSupportB);
```
**CORRE EN ARM9: sí // DEPENDE DE ARM7: no.** Conviene con `BoxSupport()` (`sdgjksupport.c`).

### `GJKWithInfo(...)` — `new_` (2.0-test)
Como BasicGJK pero reporta punto más cercano/distancia (para separar cuerpos). Úsala para física; `BasicGJK` para contacto sí/no.

### `RaycastWorld(point, dir, length, layerMask, *t, *hitInfo)` — `legacy_` (main)
Ya estaba en main marcada `ITCM_CODE` (más rápida que la de Quest84 → DESECHADOS #2). Consulta "al mundo" completo filtrando por capa.
**Parecidas:** `RayOnAABB/RayOnSphere/RayOnMesh` (primitivas sueltas para loops físicos).

### `Convert16Palette / Convert256Palette / Convert32Palette` — `legacy_` (main)
Confirmadas en `sdrender.c:1758+` (las de Quest84 eran prácticamente idénticas → DESECHADOS #3). La de 32 colores codifica alfa en los 3 bits altos.

---

## 💾 Cartuchos / RAM extra (`sdcartridge.h`) — dos HERMANAS, ambas se quedan

| | `legacy_Cartridge_GetRamSizeMb()` | `new_Cartridge_Query(CartridgeInfo*)` |
|---|---|---|
| Devuelve | 4 (DS) o 16 (DSi) | topología real: isDSi, scfgExt, slot2Size, banks |
| Cuándo usarla | decisión rápida "pack HD vs normal", evento único DSi | layout de assets externos en tus módulos W25Q/NAND/bancos |
| Ventaja | barata, simple | honesta: 0 = "desconocido", nunca inventa tamaños |
| Desventaja | no sabe de tu cartucho slot-2 | leer antes docs/CARTUCHOS_RAM.md |

```c
CartridgeInfo ci; new_Cartridge_Query(&ci);
if (ci.isDSi)       cargar_modelo_HD("models/hero.sdm");    // evento único DSi
else                cargar_modelo_normal("models/hero_lo.sdm");
if (ci.slot2Banked) seleccionar_banco_W25Q(...);             // tú defines geometría
```
**CORRE EN ARM9: sí // DEPENDE DE ARM7: no.**

## 📦 NitroFS (`nitrofs.c/h` ← Moricombe) — `new_` (rescatada; main la había borrado)
Assets embebidos en el .nds: `nitroFSInit(); fopen("models/x.sdm","rb")`.
**Cuándo:** todo lo que no necesites modificar desde SD. Complementa (no reemplaza) a `sdfile.c` sobre FAT.

## 🌐 Crossplay (`sdnetworking.h`) — `new_Crossplay_*`
Bug verificado: payload viaja crudo, 0 usos de htonl/ntohl. `PacketHeader` es seguro (packing 1, ambas CPUs LE), pero TU payload no. Regla nueva: serializa con estos helpers (LE explícito byte a byte):
```c
char buf[64]; int p = 0;
p = new_Crossplay_WriteVec3(buf, p, &playerPos);
p = new_Crossplay_WriteF32(buf, p, yaw);
PacketSendTo(buf, p, myType, false, instance);   // legacy_ intacta
```
Espejo exacto en PC (C++14, mismo orden). Ver `docs/CROSSPLAY_PC.md`.
