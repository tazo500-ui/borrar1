# ARM7_AUTONOMY.md — qué corre dónde y por qué

## Principio (dogma del proyecto)
El **ARM7 es autónomo**: nunca espera órdenes activas del ARM9 para funcionar. Maneja
hardware que SOLO él ve (audio HW, WiFi, teclado extendido DSi, energía) y responde por PXI.
El ARM9 "pide servicios" con `pxiSend`/callbacks y sigue dibujando.

## Mapa de responsabilidades en la fusión

| Tarea | CPU | Mecanismo | Etiqueta |
|---|---|---|---|
| Reproducir SFX (16 canales HW 0x04000400) | ARM7 | `PlaySound` vía `PxiChannel_User0` | slop_funcional |
| Mutar volumen/pan de canal vivo | ARM7 | `SetSoundVolume/SetSoundPan` | ported_ |
| Fin de reproducción → liberar canal | ARM7→ARM9 | callback `PlayAudioCallback` (IRQ SOUND) | legacy_ |
| WiFi (dsiwifi + lwip) | ARM7 servidor (`wlmgrStartServer`) ↔ ARM9 cliente (`dsiwifi9`) | PXI interno de dsiwifi | ported_ |
| Teclado normal + extendido DSi (ejes X/Y, bisagra) | ARM7 (`keypadStartExtServer`) | PXI | ported_/new_ |
| Reloj/vblank/threading | BlocksDS runtime (`pmMainLoop`, `threadWaitForVBlank`) | — | ported_ |
| Render 3D (GE), física GJK, colisiones, red de juego | ARM9 | directo | legacy_/new_ |
| Detección cartucho/RAM (`sdcartridge`) | ARM9 | registros SCFG/slot2 | new_ |

## Cambios del port libnds→BlocksDS (lo que ya estaba en main y se mantuvo)
- `<dswifi7.h>` → `<calico.h>` (+ dsiwifi7 binario en DSDeps).
- `fifoSendValue32(FIFO_USER_01,...)` → `pxiReply(PxiChannel_User0,...)`.
- `Wifi_Update()` en VBlank handler → eliminado: el stack lo gestiona wlmgr/lwip.
- `while(!exitflag){swiWaitForVBlank();}` → `while(pmMainLoop()){threadWaitForVBlank();}`.
- Servicios arrancados en arm7: `pmInit(); blkInit(); soundStartServer(); touchStartServer(); wlmgrStartServer(); keypadStartExtServer()`.

## Regla para funciones nuevas
Toda función nueva declara en su cabecera:
`// CORRE EN ARM7: si/no // DEPENDE DE ARM9: si/no`
Nada en ARM7 puede hacer malloc ni tocar VRAM/OAM (no los ve). Nada en ARM9 puede
escribir 0x04000400 directamente fuera del protocolo PXI establecido.

## Por qué NO se fusionó maxmod (experimento Quest84)
Quest84 añadió `<maxmod9.h>` + `mm_stream musicStream` en ARM9 sin server mm7 en ARM7
→ no reproduce (código muerto/incompleto = candidato slop_basura). La fusión conserva
el audio crudo de main (más rápido y sin dependencias). Resurrección con mm7 real: Fase 2. Ver DESECHADOS #5.
