# VERSIONES_HERMANAS.md — Catálogo de implementaciones paralelas

> **Regla del proyecto:** cuando dos o más funciones hacen la misma tarea pero vienen de
> fuentes distintas (motor original / fork / BlocksDS / nuestra fusión), **se conservan TODAS**
> y este documento dice cuál usar y cuándo, incluso si son casi indistinguibles.
> Etiquetas: `legacy_` (Yackerw) · `ported_` (adaptado a BlocksDS por nosotros) ·
> `new_` (aporte nuevo) · `slop_funcional` (técnica válida aunque incómoda) ·
> `slop_basura` (roto; reparado o reemplazado, el roto queda documentado).

---

## Familia 1 — Sonido en ARM7 (`source/arm7/source/main.c`)

| Hermana | Estado | Técnica | Cuándo usarla |
|---|---|---|---|
| `legacy_PlaySound` (ARM7) | **viva**, etiquetada `slop_funcional` | Escanea los 16 canales HW; si están llenos responde `-1` por PXI y **descarta**. Escribe registros PCM directamente (0x04000400+ch*0x10). | Siempre que necesites latencia mínima y determinismo sin malloc en ARM7. El `-1` es tu señal: haz la cola TÚ en ARM9. |
| `ported_PlaySound_Pitched` | viva | Igual + `SOUND_FREQ(mulf32(sampleRate,pitch))` | Cualquier efecto con pitch (el legacy puro ignoraba pitch). |
| Cola de sonido estilo "reintento" | **patrón documentado, no función hecha** | Recibes `-1` de PlaySound → guardas el pedido en un arreglo tuyo y reintentas cuando un canal se libere (`StopSoundEffect`) | Fuegos cruzados, UI rápida, >16 sonidos simultáneos. Ejemplo de implementación en GUIA_NOVATOS §8. Si quieres que exista como función oficial `new_Sound_QueuePlay`, es ticket de Fase 2. |
| `legacy_SetSoundPan/Vol` | **reparada** → `ported_SetSoundPan/Vol` | Usaba `&= !((0x7F)<<16)` (`!` lógico en vez de `~` bitwise) → limpiaba el registro entero. Bug `slop_basura`. | No usar las viejas; existen solo como historia comentada en el código. |
| `new_Sound_StreamWav` (experimento maxmod9 de Quest84) | **NO fusionada** | Streaming .wav vía mm_stream | Ver DESECHADOS.md §D-3: requiere reintroducir maxmod7 en ARM7, choca con wlmgr/pm de BlocksDS. Documentada para fase 2. |

**Dos técnicas legítimas conviviendo (decisión tuya, usuario):** generación cruda por
código (lego-style, escribiendo muestras tú mismo) vs reproducción de archivo (.sdi/.wav
precargado). Ambas se quedan: `legacy_PlaySound` cubre la primera, `LoadWav/PlayMusic`
+ loader `.sdi` la segunda. Ninguna es "mejor": la cruda no necesita assets, la de archivo
no necesita DSP propio. Ejemplo crudo mínimo está en API_REFERENCE.md §Sonido.

---

## Familia 2 — Detección de RAM / cartucho (`sdcartridge.c/h`)

| Hermana | Origen | Qué devuelve | Cuándo usarla |
|---|---|---|---|
| `legacy_Cartridge_GetRamSizeMb()` | Idea de Meta/Qwen (límite canónico DS=4MB, DSi=16MB vía `isDSiMode()`) | 4 o 16 exactos | Código simple tipo "si DSi → texturas 256²". Barato, sin slot-2. |
| `new_Cartridge_Query(CartridgeInfo*)` | BlocksDS `slot2.h` (geometría real: tamaño/banks/chips W25Q, NAND, etc.) | Topología real o campos 0 = desconocido | Tus cartuchos personalizados multi-chip (2×16, 8, 32…). La única que ve banks reales. |
| nota: la deteccion DSi vive dentro de new_Cartridge_Query (campo isDSi) | hybrid | wrapper `isDSiMode()` + lectura `REG_SCFG_EXT` | Eventos exclusivos DSi (cámara/mic/keypad ext ya usados en arm7). |

**Las dos primeras son HERMANAS declaradas**: la arbitraria 4/16 no se borró (pediste
que sirva como camino fácil); la documentación simplemente **recomienda `new_Cartridge_Query`
como fuente de verdad** porque no inventa topologías. Si `new_Cartridge_Query` reporta 0
(hardware desconocido), cae a la legacy como fallback — patrón documented en el código.

---

## Familia 3 — Colisiones (`sdcollision.c`, `sdgjksupport.c`)

| Hermana | Fuente | Estado | Notas |
|---|---|---|---|
| `BasicGJK` versión main vieja | Yackerw | **`slop_basura` reparada** | Bucle `while(true)` sin procesar simplex. Guardada intacta en `legacy_sdcollision_main.c` como referencia histórica. |
| `BasicGJK`/`GJKWithInfo` + `Simplex` + `GJKProcessSimplex2/3/4` | Example **2.0-test** | **viva, es la base actual** | Con `GJK_LENIENCY 32`; usa helpers `divf32f`/matrix-stack de sdmath ported. |
| `BoxOnBox/SphereOnSphere/RayOnAABB/SphereOnOBB` | main (absorbió Moricombe) | vivas | OBB es aporte Moricombe; RayOnAABB *sin normal* era versión Quest84 → descartada (ver DESECHADOS §D-2). |
| `new_RaycastWorld()` | Quest84 | viva (en main ya existía mejorada con `ITCM_CODE`) | Conservamos la firma de Quest84 como wrapper fino para compatibilidad de ejemplos viejos. |

---

## Familia 4 — Networking crossplay (`sdnetworking.c`, `sdsocket.c`)

| Hermana | Endianness | Cuándo |
|---|---|---|
| `PacketSendTo/PacketRecvFrom` (`legacy_`) | ❌ ninguno (bug real: 0 usos de htonl/ntohl en original) | Solo DS↔DS (ambos little-endian → funciona por accidente benigno). |
| `new_Crossplay_WriteI32/F32/Vec3` + `Read…` | ✅ LE explícito serializado byte a byte | Todo tráfico DS↔PC. No toca las legacy para no romper multiplayer DS-local existente. |
| WiFi stack: `dswifi7 Wifi_Update()` (libnds) vs `wlmgrStartServer()` (BlocksDS) | — | BlocksDS gana siempre; el viejo quedó atrás con la portación de rainscut→main. |

---

## Familia 5 — Paletas/texturas (`sdrender.c`)

| Hermana | Bit depth | Nota |
|---|---|---|
| `Convert16Palette` / `Convert256Palette` (Quest84→main) | 4bpp / 8bpp estándar DS | Las de Quest84 eran idénticas funcionalmente; se quedaron las de main. |
| `Convert32Palette` + **2bpp/5-bit alpha** | commit `5060573` de main (viene del example 2.0) | Novedad real: 4 colores por tile con alpha de 5 bits. Úsala para sprites con sombra barata. |

---

## Familia 6 — Input (`sdinput.c` + arm7)

| Hermana | Fuente | Ventaja exclusiva |
|---|---|---|
| `legacy_Input_*` (hidTouch/swiWaitForVBlank) | libnds | Ninguna hoy; se conserva API para ejemplos 1.0. |
| API input del **example 2.0-test** | fork ejemplo | Más limpia; es la recomendada en API_REFERENCE. |
| `keypadStartExtServer()` (arm7) | BlocksDS/DSi | **Solo DSi**: ejes analógicos extra y estado de bisagra → la usamos como disparador natural de "eventos únicos DSi" que pediste. |

---

## Cómo leer cada ficha en API_REFERENCE.md
Cada entrada lleva: qué hace · ejemplo compilable · hermanas · ventajas/desventajas ·
con qué va bien · categoría de etiqueta · corre en ARM7 sí/no · depende de ARM9 sí/no.
