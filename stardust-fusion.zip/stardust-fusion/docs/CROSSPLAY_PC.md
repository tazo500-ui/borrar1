# CROSSPLAY_PC.md — DS ↔ PC (GLFW+GLEW, no SDL)

## Arquitectura real del código (verificada leyendo el repo)
```
DS (ARM9)                          PC (Windows 7-10, VS2019/2022, C++14)
 sdnetworking.c (lwip sockets)  <-> pc/sdsocket.cpp (WinSock2 UDP)
 PacketHeader packed(1) LE         mismo struct espejo
 payload CRUDO = BUG               payload CRUDO = BUG
```
- Librerías PC: **glfw-3.3.bin.WIN32 + glew-2.1.0** (`source/VSDeps`, lib-vc2019). Solución: `source/StarDust.sln` (plataformas Win32/x64). Nada de SDL.
- Render PC: OpenGL inmediato-ish con shaders propios (`PC/Renderer/OpenGL`), lee los mismos `.sdm/.sda`.

## Por qué estaba "roto" el crossplay (causas verificadas)
1. **Endianness/padding del payload:** `PacketSendTo` hace `memcpy` del buffer crudo del juego. ARM y x86 son ambos little-endian, PERO structs del juego con `f32`+padding o compilados distinto packing en MSVC vs GCC invierten/desalinean campos → posiciones fantasma. En el motor NO había ningún helper de serialización (grep htonl/ntohl = 0 resultados).
2. **NETVER/NETAUTH:** el handshake compara versión y string de autenticación; si recompilas un lado y olvidas `-DNETVER`, el otro lado descarta paquetes silenciosamente.
3. **Stack de importantes:** si superas `maxPackets/2` paquetes importantes sin ACK, `CloseConn` cierra la conexión (por diseño, pero sorprende).

## Fix Fase 1: capa `new_Crossplay_*` (en `sdnetworking.h/c`)
Little-endian explícito byte a byte, válido en cualquier CPU/compiler:
```c
// DS
char buf[64]; int p = 0;
p = new_Crossplay_WriteVec3(buf, p, &pos);   // 3x i32 (fixed16 f32 del motor)
p = new_Crossplay_WriteF32(buf, p, yaw);
PacketSendTo(buf, p, PLAYER_SYNC, false, instance);
```
```cpp
// PC (espejo exacto, mismo orden; implementa los mismos helpers en sdsocket.cpp)
int p = sizeof(PacketHeader); // tras validar header
Vec3 pos; p += ReadVec3LE(buf, p, &pos);
float yaw = ReadF32LE(buf, p);
```
Regla: **nunca** enviar structs con `memcpy` directo como payload; solo bytes planos serializados. El `PacketHeader` se mantiene binario-compatible (packing 1, tipos de tamaño fijo).

## Cómo probarlo
1. PC: abrir `source/StarDust.sln` en VS2019 (toolset v142 = Win7 SP1+ compatible), F5 (host en puerto por defecto del ejemplo).
2. DS: ROM cliente con `-DSTARDUST_NETWORKING=1`, misma `NETVER`/`NETAUTH`.
3. Router sin aislamiento AP; DS solo soporta 2.4 GHz.

## Limitaciones conocidas (Fase 2)
- Sin WPA2 propio en API del motor (dsiwifi maneja asociación; exponer API limpia pendiente).
- Sin compresión/delta de estado (existe `sddelta.c` para animaciones, no red).
- IPv4 only en la práctica del ejemplo.
