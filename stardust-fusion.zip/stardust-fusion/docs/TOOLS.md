# TOOLS.md — Pipeline de herramientas StarDust (Blender 2.79, convertidores)

> Documento verificado contra el código real en `source/blender/` y `source/imageConverter/`.
> Nada de esto es especulación: cada afirmación tiene número de línea del archivo fuente.

---

## 1. ¿Qué existe REALMENTE en la pipeline?

| Herramienta | Ruta en el repo | Qué hace | Versión requerida |
|---|---|---|---|
| **Exportador `.sdm`** (modelo) | `source/blender/io_mesh_sdm/__init__.py` (919 líneas) | File → Export → Stardust model (.sdm) | **Blender 2.79 exacto** |
| **Exportador `.sda`** (animación) | `source/blender/io_mesh_sda/__init__.py` (456 líneas) | File → Export → Stardust animation (.sda) | **Blender 2.79 exacto** |
| **SDImageConverter** (C#) | `source/imageConverter/SDImageConverter.sln` + `Program.cs` | Convierte PNG/BMP a `.sdi` (texturas con paleta DS) | .NET Core 3.1 (VS2019 toolset v142, Win7-10 OK) |
| ~~Loader `.obj`~~ | **NO EXISTE** | — | — |

### ⚠️ Aclaración histórica importante (por qué casi nos equivocamos los tres)
En las primeras conversaciones se mencionó un *"loader OBJ de Blender en rainscut"*.
**Falso.** Verificado con búsqueda en los 3 forks: no hay ningún `objLoader.c` ni lectura
de `.obj` en runtime en ningún repo. Lo que sí existe —y por eso tu memoria era correcta—
es el **exportador custom de Blender** que escribe directamente el binario `.sdm`.
La diferencia es conceptual:
- Un *loader* lee el formato abierto de otro programa en tiempo de ejecución.
- Un *exportador* convierte desde el editor nativo (Blender) al formato propio en escritorio.
StarDust usa exportador. El motor en la DS solo entiende `.sdm`/`.sda`/`.sdi`.

### Por qué Blender 2.79 y no 3.x (y por qué lo dejamos así)
Ambos add-ons declaran en su `bl_info`:
```python
"blender": (2, 79, 0),   # io_mesh_sdm/__init__.py:12 e io_mesh_sda/__init__.py:11
```
Motivos técnicos reales, no vagancia del autor:
1. Usan la **API de 2.7x**: `bpy.context.scene.objects`, acceso directo a `mesh.vertices/tessfaces`,
   armatures con `pose.bones[i].matrix` del sistema viejo. En Blender ≥2.8 la API cambió a
   `evaluated_depsgraph_get()`, `mesh.loops`, y el espacio de trabajo Z-up→Y-up; portar requiere
   reescribir la conversión de coordenadas o los modelos salen rotados/reflejados.
2. El cuantizado a enteros de 16 bits (véase §2) depende de cómo 2.79 entrega los locales
   de los bones; replicarlo en 3.x sin tests visuales contra hardware real es arriesgado.
3. **Tú tienes 2.79 y aceptas sus limitaciones** → decisión del proyecto: NO se porta ahora.
   Queda anotado como tarea futura opcional (FASE 3) con checklist de migración abajo.

---

## 2. Formato `.sdm` según lo que ESCRIBE el exportador (deducido del código)

Del `execute()` de `io_mesh_sdm/__init__.py` (línea 895+) y los helpers de escritura:

```python
write_int  → struct.pack("<1i", value)    # int32 little-endian      (línea 422)
write_float→ struct.pack("<1i", int(v))   # ¡OJO! float trunco a int (línea 427)*
write_short→ struct.pack("<1h", ...)      # int16 LE                 (línea 431)
write_byte → struct.pack("<1B", ...)      # uint8 LE                 (línea 445)
```
*Los vértices se guardan como **int16** (`write_vertex`, l.439): el motor trabaja en
coordenadas fijas de sub-píxel, y por eso Blender "solo" exporta enteros cuantizados.
Las texturas se referencian **por nombre de imagen sin extensión**, y si un material
no tiene textura se escribe literalmente `"white.sdi"` (l.838-841).

Consecuencias prácticas para ti (reglas del editor):
- Nombra tus imágenes dentro de Blender pensando en el archivo `.sdi` resultante
  (`brick.png` → busca `brick.sdi` en la ROM/tarjeta).
- Mantén las escalas del modelo cerca de ±32767/escala interna; valores fuera se recortan.
- Los huesos sin vertex group solían crashear el exportador → fix upstream
  `c700923 "Fix errors being thrown if a bone exists but isn't assigned to a vertex group"`
  (ya incluido en nuestra base main). Si usas el add-on descargado de la wiki vieja,
  asegúrate de que tenga ese fix.

## 3. Instalación del add-on en Blender 2.79 (paso a paso)

1. Abre Blender 2.79 → `File → User Preferences → Add-ons → Install Add-on...`
2. Selecciona `io_mesh_sdm/__init__.py` (renómbralo antes a `io_mesh_sdm.py`, o ponlo en
   la carpeta `addons/io_mesh_sdm/` de tu perfil de Blender 2.79).
3. Marca la casilla *Enable*, guarda preferencias (Ctrl+U). Repite con `io_mesh_sda`.
4. Exporta: `File → Export → Stardust model (.sdm)` / `Stardust animation (.sda)`.
5. Convierte texturas con SDImageConverter y mete todo en `source/nitrofiles/`
   (nuestra fusión añade `nitrofs.c/h` de Moricombe → los assets viajan **dentro de la ROM**,
   sin tarjeta, funcionando idéntico en DS y DSi).

## 4. Limitaciones conocidas del pipeline 2.79 (sé honesto contigo mismo)

| Limitación | Impacto | Workaround hoy |
|---|---|---|
| Sin importador `.obj`/`.fbx`→sdm directo | Modelos de otros programas: primero ábrelos en Blender 2.79 (importador obj SÍ trae Blender), luego exporta sdm | Aceptable: el obj-importer de Blender normaliza unidades |
| UVs y paletas: máx 15 colores + transparente por tile 8×8 (formato DS) | Texturas "artísticas" pierden detalle | Usa SDImageConverter con dithering; FASE 2 propone compresión LZ + paletas DSi extendidas |
| Animación `.sda` ligada a rig del `.sdm` | Renombrar huesos rompe animaciones | Bloquea nombres de huesos tras el primer export |
| Blender 2.79 ya no recibe parches | Bug raro = lo arreglas tú | El add-on son ~1400 líneas de Python legible; tenemos copia versionada en este repo ✅ |

## 5. Tarea futura (FASE 3, documentada pero NO hecha) — port a Blender 3.x/4.x

Checklist mínimo para quien lo intente (no inventar atajos):
1. Reemplazar `tessfaces`/`mesh.vertices` por `depsgraph` + `loops`; validar winding.
2. Compensar Y-up↔Z-up en la matriz de exportación y **verificar en hardware**, no solo en PC.
3. Añadir opción *Apply Modifiers* (2.79 no lo hacía; meshes con mirror/subsurf salían mal).
4. Bonus pedido por el usuario: script `blender_to_sdm.py` headless (`blender -b -P`) para
   batch-export sin abrir la GUI. Viable en 2.79 también (`--background`).
5. Regla dogmática del proyecto: el port nuevo se etiqueta `new_Exporter_Blender3x` y el
   viejo se queda intacto como `legacy_Exporter_Blender279`. Nadie borra nada.

## 6. Dónde encaja esto con las etiquetas del proyecto

- `legacy_` : add-ons tal cual los escribió Yackerw (conservados en `source/blender/`).
- `ported_` : (futuro) add-on adaptado a Blender 3.x.
- `new_`    : (fase 2/3) `blender_to_sdm.py` batch, inspector tipo Unity.
- `slop_funcional`: escribir floats como `struct.pack("<1i", int(v))` (l.427) — pierde
  decimales **a propósito** porque el formato es de punto fijo; se conserva con esta ficha.
- `slop_basura`: ninguno encontrado en los add-ons (el crash de bones ya está fixeado arriba).
