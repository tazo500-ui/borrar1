# BUILD_BLOCKSDS.md — por qué BlocksDS y cómo compilar la fusión

## Por qué se abandona libnds/devkitPro clásico
| | libnds (devkitPro) | BlocksDS |
|---|---|---|
| Estado | mantenimiento mínimo, API FIFO vieja | activo, toolchain integrado (devkitARM r68+) |
| Servicios | ninguno (tú haces el fifo handler) | calico: `pm`, `pxi`, `wlmgr`, `sound`, `touch`, threading (`threadWaitForVBlank`) |
| DSi | parches sueltos | soporte real: `isDSiMode()`, SCFG, keypad extendido, slot-2 con detección de perifericos |
| WiFi moderno | dswifi7 (sin DSi) | compatible + `dsiwifi`/lwip (como usa este motor) |
| Riesgo | — | rompe includes/APIs viejas → por eso existe `ported_` |

**El error clásico que reportaban los issues** (`fatal error: calico.h: No such file or directory`) NO era porque main no estuviera portado: el código ya usaba calico, pero los **Makefiles seguían con `LIBDIRS := $(LIBNDS)`**. Fix aplicado en esta fusión: `$(BLOCKSDS)/sys` + `$(BLOCKSDS)/nds` (+`portlibs` en ARM9), con `$(error ...)` claro si falta la variable.

## Requisitos
1. Instalar BlocksDS (script oficial de su web) → exporta `BLOCKSDS` en tu shell.
2. Verificar: `echo $BLOCKSDS && ls $BLOCKSDS/nds/include/calico.h`.

## Compilar
```bash
cd stardust-fusion/source
make -j        # arma arm7/, arm9/ y ndstool -> StarDust.nds
```
(El Makefile raíz delega a arm7/arm9 como siempre; ahora ambos ven BlocksDS.)

## Ajustes que pide la fusión al primer build (esperados, resuelve así)
- Símbolos duplicados entre `legacy_sdcollision_main.c` y `sdcollision.c`: el archivo legacy está para lectura/documentación; si molesta al linker, coméntalo en `SOURCES` o bórralo del glob (NO del repo).
- `sdmath.h` viene de Example 2.0-test: añade funciones (`divf32f`, matrix stack); si algún `.c` de main definía algo con el mismo nombre, renómbralo con prefijo `legacy_`.
- DSDeps (libdsiwifi*.a + headers lwip) siguen siendo binarios del autor: se enlazan tal cual vía `../../DSDeps/`.

## Probar en hardware/emulador
- melonDS (soporta DSi) o TWiLight Menu++ en consola real.
- Prueba de humo: audio (PlaySound + pan/volumen ahora correctos), colisiones GJK, `new_Cartridge_Query()` imprimiendo `isDSi/baseRamMb/slot2Size`.

## Referencia histórica
Los árboles viejos (`investigation/Moricombe`, `Quest84`, `rainscut`) quedan en el repo de investigación como referencia `legacy_` compilable solo con devkitPro antiguo. No mantenerlos vivos.
